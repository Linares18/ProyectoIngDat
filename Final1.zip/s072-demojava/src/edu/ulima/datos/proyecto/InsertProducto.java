/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ulima.datos.proyecto;

import edu.ulima.datos.proyecto.bean.Producto_Q;
import edu.ulima.datos.proyecto.bean.Usuario;
import edu.ulima.datos.util.JdbcUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author Giancarlos
 */
public class InsertProducto {
    public static void registrarProducto(Producto_Q prod) throws Exception{
        Connection conn = JdbcUtil.getConnection();
        String sql = "INSERT INTO PRODUCTO VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, prod.getCod_producto());
        pst.setFloat(2, prod.getPrecio());
        pst.setString(3, prod.getLink());
        pst.setString(4, prod.getNombre());
        pst.setFloat(5, prod.getProfundidad());
        pst.setFloat(6, prod.getAltura());
        pst.setFloat(7, prod.getAncho());
        pst.setFloat(8, prod.getPeso());
        pst.setString(9, prod.getCategoria());
        pst.executeUpdate();
        pst.close();
        conn.close();
    }     

    public static void main(String[] args) throws Exception{
        
        Producto_Q prod1 = new Producto_Q(100, 159, "www.amazon.com", "procesador", 1.5f, 1.5f, 1.5f , 1.0f  , "Gaming");
        Producto_Q prod2 = new Producto_Q(200, 80, "www.ebay.com", "teclado", 2f, 15f, 1f , 10f, "Gaming");
        registrarProducto(prod1);
        registrarProducto(prod2);
        
        System.out.println("Productos registrados correctamente");
    }
}
